<?php

class Services_Twilio_Rest_Trunking_CredentialList extends Services_Twilio_TrunkingInstanceResource {

}
